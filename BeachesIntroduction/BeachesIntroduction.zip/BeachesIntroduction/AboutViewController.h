//
//  AboutViewController.h
//  BeachesIntroduction
//
//  Created by Mac on 11/1/13.
//  Copyright (c) 2013 MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@end
